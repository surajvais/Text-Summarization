from flask import Flask,render_template, request
import a

app = Flask(__name__)

@app.route('/',methods = ['POST', 'GET'])
def index():
	if request.method == 'POST':
		text = str(request.form['text'])
		summary = a.summarize(text)
		return render_template("home.html",summary = summary)
	return render_template("home.html",summary = "")

if __name__ == '__main__':
	app.run()
